echo enter character
read n
ls $n*

